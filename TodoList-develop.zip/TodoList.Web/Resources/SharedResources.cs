﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TodoList.Localization.Shared
{
    // Stub class required for having a SharedResource.resx file working properly
    public class SharedResources
    {
    }
}
